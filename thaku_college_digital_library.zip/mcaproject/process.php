<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$db = "phplogin";

$conn = new mysqli($dbhost,$dbuser , $dbpass , $db);
$username = $_POST['username'];
$password = $_POST['password'];
$sql = "SELECT * FROM user WHERE username = '$username' AND password = '$password'" ;
$result = mysqli_query($conn,$sql);
$row = mysqli_fetch_array($result);
if
($row ['username'] == $username && $row['password'] == $password)
{
    echo " <script> location.href='cources.html'</script>";
}
else{
     echo "YOU ARE NOT AUTHENTIC PERSON";
 
}

?>


