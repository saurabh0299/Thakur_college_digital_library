var password = "123";
var password1 = "1234";
function passcheck()
{
    if (document.getElementById('pass1 , pass2').value != password ,password1)
    

    {
        alert('wrong password, Try Again.');
        return false;

    }
    if (document.getElementById('pass1,pass2').value == password,password1)


    {
        alert('correct password. Click ok to enter webpages.');

    }

}