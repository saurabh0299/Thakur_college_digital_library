<!DOCTYPE html>
<html>
    <head> <link rel="stylesheet" href="loginsystem.css">
 <style >
    body{
        background-image: url('L4.jpg');
        background-repeat: no-repeat;
        background-size: 100% 100%;
        background-attachment: fixed;
    
    }
 </style> 



</head>
<body>
    <div class="L1">
        <h1 > LOGIN  </h1> </div>
    <div class="center">
       
    <form    action="loginprocess.php"  method="POST">
        <div class="txt_field">
          <input type="text"   id="user"   name="email"   required>
          <span></span>
          <label>Email-ID</label>
        </div>
        <div class="txt_field">
          <input type="password"  id="pass"   name="pass"       required>
          <span></span>
          <label>Password</label>
        </div>

        <input type="submit"   id="btn" value="Login">
    </form>
    </div>






</body>
</html>


