




<!DOCTYPE html>
<html>
    <head> <link rel="stylesheet" href="loginsystem.css">
 <style >
    body{
        background-image: url('L4.jpg');
        background-repeat: no-repeat;
        background-size: 100% 100%;
        background-attachment: fixed;
    
    }
 </style> 



</head>
<body>
    <div class="L1">
        <h1 > LOGIN  </h1> </div>
    <div class="center">
       
    <form   method="POST" action="process.php">
        <div class="txt_field">
          <input type="text"   id="username"   name="username"   required>
          <span></span>
          <label>Email-ID</label>
        </div>
        <div class="txt_field">
          <input type="password"  id="password"   name="password"       required>
          <span></span>
          <label>Password</label>
        </div>

        <div class="txt_field">
            <input type="mcacode"   id="mca1"   name="mca1"   >
            <span></span>
            <label>MCA Code</label>
          </div>
        
        <input type="submit"   id="btn" value="Login">
    </form>
    </div>






</body>
</html>


